package com.example.mazhar_quizapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
